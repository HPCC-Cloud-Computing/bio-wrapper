// +build !linux

package daemon

func installDefaultAppArmorProfile() {
}

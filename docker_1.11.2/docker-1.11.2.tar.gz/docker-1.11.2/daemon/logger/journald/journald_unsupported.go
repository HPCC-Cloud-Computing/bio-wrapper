// +build !linux

package journald

type journald struct {
}

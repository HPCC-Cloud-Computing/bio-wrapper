package credentials

const defaultCredentialsStore = "secretservice"

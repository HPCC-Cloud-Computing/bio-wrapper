package credentials

const defaultCredentialsStore = "osxkeychain"

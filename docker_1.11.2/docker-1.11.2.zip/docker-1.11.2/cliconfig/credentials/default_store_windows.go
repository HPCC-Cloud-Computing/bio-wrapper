package credentials

const defaultCredentialsStore = "wincred"
